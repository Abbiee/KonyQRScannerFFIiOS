/**
 * @module modbarcode
 *
 * @author Arun Thallapelly <arun.thallapelly@kony.com>
 */

function launchBarcodeCapture(){
	barcode.captureBarcode(barcodeCapCallback);
}

function barcodeCapCallback(barcodedata, androidScannedText){
	var platformName = kony.os.deviceInfo().name;
	if(kony.string.startsWith(platformName, "iphone", true)){
		frmHome.txtServicetag.text = (""+barcodedata.barcodestring).toUpperCase();
	}else if(kony.string.startsWith(platformName, "android", true)){
		frmHome.txtServicetag.text = androidScannedText.toUpperCase();
	}
	
}