//actions.js file 
function AS_Button_c4c4469e912d4014bc1bc7b1819cc7c0(eventobject) {
    return launchBarcodeCapture.call(this);
}