function skinsInit() {
    CopyslButtonGlossBlue00f0880d7c79d49 = "CopyslButtonGlossBlue00f0880d7c79d49";
    CopyslButtonGlossRed03210fdd8d9a04f = "CopyslButtonGlossRed03210fdd8d9a04f";
    CopyslForm0ebae1713ad4c49 = "CopyslForm0ebae1713ad4c49";
    CopyslTextBox09472f7557e2545 = "CopyslTextBox09472f7557e2545";
    CopyslTextBox09e388f04467b4b = "CopyslTextBox09e388f04467b4b";
    sknTitleBar = "sknTitleBar";
    slButtonGlossBlue = "slButtonGlossBlue";
    slButtonGlossRed = "slButtonGlossRed";
    slDynamicNotificationForm = "slDynamicNotificationForm";
    slFbox = "slFbox";
    slForm = "slForm";
    slPopup = "slPopup";
    slStaticNotificationForm = "slStaticNotificationForm";
    slTextBox = "slTextBox";
    slTitleBar = "slTitleBar";
    slWatchForm = "slWatchForm";
};