function addWidgetsfrmHome() {
    frmHome.setDefaultUnit(kony.flex.DP);
    var flxManualServiceTag = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "height": "10%",
        "id": "flxManualServiceTag",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox",
        "top": "30dp",
        "width": "95%"
    }, {}, {});
    flxManualServiceTag.setDefaultUnit(kony.flex.DP);
    var txtServicetag = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "height": "100%",
        "id": "txtServicetag",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "3%",
        "placeholder": "Scanned Text",
        "secureTextEntry": false,
        "skin": "CopyslTextBox09472f7557e2545",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "0dp",
        "width": "65%"
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "placeholderSkin": "CopyslTextBox09e388f04467b4b",
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var btnScan = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossRed03210fdd8d9a04f",
        "height": "100%",
        "id": "btnScan",
        "isVisible": true,
        "left": "70%",
        "onClick": AS_Button_c4c4469e912d4014bc1bc7b1819cc7c0,
        "skin": "CopyslButtonGlossBlue00f0880d7c79d49",
        "top": "0dp",
        "width": "27%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxManualServiceTag.add(
    txtServicetag, btnScan);
    frmHome.add(
    flxManualServiceTag);
};

function frmHomeGlobals() {
    frmHome = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmHome,
        "enabledForIdleTimeout": false,
        "id": "frmHome",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "skin": "CopyslForm0ebae1713ad4c49",
        "title": "Barcode Scanner"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "sknTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_RESIZE
    });
};